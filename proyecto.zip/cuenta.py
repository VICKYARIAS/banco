#ARIAS RAMIREZ VICTORIA ANGÉLICA
import sys
class Cuenta:
  
  def __init__(self,valor):
   
    self.cantidad= valor
  
  def depositar(self,valor):
  
    if valor>0:
  
      self.cantidad=self.cantidad+valor
  
    else:
  
      print("El valor a depositar es incorrecto")
    
  def retirar (self,valor):
    
    if valor>0:
      if valor<=self.cantidad:
        self.cantidad=self.cantidad-valor
      else:
        print("Saldo insuficiente")
    else:
      print("Cantidad errónea")

  def getCantidad(self):
      return self.cantidad
  
  def __str__(self):
    #con ééste méétodo ya podemos imprimir llamando al objeto únicamente
    return "La cantidad de su cuenta es: " + str(self.cantidad)
